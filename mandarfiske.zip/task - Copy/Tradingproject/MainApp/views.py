

# Create your views here.


from django.http import JsonResponse
from django.shortcuts import render
from .models import Candle

def csv(request):
    if request.method == 'POST' and request.FILES.get('csv_file'):
        csv_file = request.FILES['csv_file']
        timeframe = int(request.POST.get('timeframe', 1))  # Default 1 minute

        # Save the CSV file on the server
        with open('uploaded.csv', 'wb+') as destination:
            for chunk in csv_file.chunks():
                destination.write(chunk)

        # Read and process the CSV file
        # Implement the CSV reading and candle conversion logic here

        # Store converted data into a JSON file

        # Provide a download link to the JSON file
        # Implement the file download logic

        return JsonResponse({'message': 'Data processed successfully'})

    return render(request,'Mainapp/csv.html')
