

from django.urls import path, include
from MainApp import views

urlpatterns = [

    path('', views.csv),
]